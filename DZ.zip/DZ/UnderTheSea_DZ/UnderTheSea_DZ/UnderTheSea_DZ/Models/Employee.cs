﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ
{
    public class Employee
    {

        public string Username { get; set; }
        public string Password { get; set; }
        public int EmployeeId { get; set; }
        public int DepartmentId { get; set; }
        public string Status { get; set; }
        public string Salary { get; set; }
        public string Violation{ get; set; }
        public string Name { get; set; }
        public string RequestPermit{ get; set; }

        public List<Employee> GetAllEmployee()
       {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Employee>($"select * from Employee").ToList();
                return output;
            }
       }

        public List<Employee> GetEmployee(int employeeID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Employee>($"select * from Employee where Employee.employeeID = " + employeeID + "").ToList();
                return output;
            }
        }
        public List<Employee> GetEmployeeWithPermitRequest()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Employee>($"select * from Employee where Employee.RequestPermit = 'Waiting for confirmation'").ToList();
                return output;
            }
        }



        public List<Employee> GetAllEmployeeWithNoSchedule()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Employee>($"select * from Employee where EmployeeID not in (select EmployeeID from Schedule)").ToList();
                return output;
            }
        }

        public void Employee_Insert(string Username , string Password , int DepartmentID, int DivisionID , string Status , int Salary , string Violation, string Name, string RequestPermit)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Employee_Insert @Username , 'DZ20-1', @DepartmentID, @DivisionID , 'Working' ,@Salary , NULL, @Name, NULL", new { Username, Password, DepartmentID, DivisionID, Status, Salary, Violation, Name,  RequestPermit });
            }
        }

        public void EmployeeStatus_Update(int EmployeeID, string status, string violation)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Employee_Update @EmployeeID  , @Status, @Violation  ", new { EmployeeID, status , violation});
            }
        }

        public void FireEmployee(int EmployeeID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Fire_Employee @EmployeeID", new { EmployeeID });
            }
        }


        public void PermitRequest_Update(int EmployeeID, string status)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.PermitRequest_Update @EmployeeID, @Status", new { EmployeeID, status});
            }
        }

        public void RaiseEmployeeSalary(int EmployeeID, int Salary)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.RaiseEmployeeSalary @EmployeeID, @Salary", new { EmployeeID, Salary});
            }
        }


        public void Employee_Delete(int EmployeeID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Employee_Delete @EmployeeID ", new { EmployeeID });
            }
        }
        public List<Employee> GetLastEmployee()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Employee>($"select TOP 1 * from Employee ORDER BY EmployeeID DESC").ToList();
                return output;
            }
        }



    }

}

﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class Request
    {
        public int RequestID{ get; set; }
        public int SenderID{ get; set; }
        public int ReceiverID{ get; set; }
        public string Status{ get; set; }
        public string Description{ get; set; }
        public int additionalID{ get; set; }

        public Request()
        {

        }

        public List<Request> GetRequest(int RequestID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select * from Request where Request.RequestID = " + RequestID + "").ToList();
                return output;
            }
        }
        public List<Request> GetAllRequest()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select * from Request").ToList();
                return output;
            }
        }

        public List<Request> GetAllPurchaseRequest()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select * from Request where receiverID = 6").ToList();
                return output;
            }
        }

        public List<Request> GetAllFundRequest()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select * from Request where receiverID = 7").ToList();
                return output;
            }
        }

        public List<Request> GetAllManagerRequest()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select * from Request where receiverID = 11").ToList();
                return output;
            }
        }


        public void Request_Insert(int SenderID, int ReceiverID, string Status, string Description, int AdditionalID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Request_Insert @SenderID, @ReceiverID, @Status, @Description, @AdditionalID", new { SenderID, ReceiverID, Status, Description, AdditionalID });
            }
        }

        public void Request_Update(int RequestID, string Status)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Request_Update @RequestID, @Status", new { RequestID, Status });
            }
        }

        public void Request_Delete(int RequestID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Request_Delete @RequestID ", new { RequestID });
            }
        }

        public List<Request> GetLastRequest()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select TOP 1 * from Request ORDER BY RequestID DESC").ToList();
                return output;
            }
        }
    }
}

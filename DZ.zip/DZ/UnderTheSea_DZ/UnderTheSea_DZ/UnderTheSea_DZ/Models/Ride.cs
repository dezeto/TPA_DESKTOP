﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class Ride
    {
        public int RideID { get; set; }
        public string RideName { get; set; }
        public string RideStatus { get; set; }
        public string RideDescription { get; set; }

        public List<Ride> GetRide(int RideID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Ride>($"select * from Ride where Ride.RideID = " + RideID + "").ToList();
                return output;
            }
        }
        public List<Ride> GetAllRide()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Ride>($"select * from Ride").ToList();
                return output;
            }
        }

        public List<Ride> GetAllRideWithNoSchedule()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Ride>($"select * from Ride where RideID not in (select RideID from Schedule)").ToList();
                return output;
            }
        }

        public void Ride_Insert(string rideName, string rideStatus, string rideDescription)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Ride_Insert @RideName, @RideStatus, @RideDescription, NULL ", new { rideName, rideStatus, rideDescription});
            }
        }

        public void RideStatus_Update(int rideID, string status)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.RideStatus_Update @RideID, @status", new { rideID, status});
            }
        }

        public void Ride_Delete(int RideID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Ride_Delete @RideID ", new { RideID });
            }
        }
        public List<Ride> GetLastRide()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Ride>($"select TOP 1 * from Ride ORDER BY RideID DESC").ToList();
                return output;
            }
        }


    }
}

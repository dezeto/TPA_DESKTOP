﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class Department
    {
        public int DepartmentID { get; set;}
        public string DepartmentName{ get; set; }
        public List<Department> GetAllDepartment()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Department>($"select * from Department").ToList();
                return output;
            }
        }
        public List<Department> GetDepartment(int departmentID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Department>($"select * from Department where Department.departmentID = "+departmentID+"").ToList();
                return output;
            }
        }

    }
}

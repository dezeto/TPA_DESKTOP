﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class Attraction
    {
        public int AttractionID { get; set; }
        public string AttractionName { get; set; }
        public string AttractionStatus { get; set; }
        public string AttractionDescription { get; set; }

        public List<Attraction> GetAttraction(int AttractionID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Attraction>($"select * from Attraction where Attraction.AttractionID = " + AttractionID + "").ToList();
                return output;
            }
        }

        internal void Attraction_Delete(object attractionID)
        {
            throw new NotImplementedException();
        }

        public List<Attraction> GetAllAttraction()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Attraction>($"select * from Attraction").ToList();
                return output;
            }
        }


        public void Attraction_Insert(string AttractionName, string AttractionStatus, string AttractionDescription)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Attraction_Insert @AttractionName, @AttractionStatus, @AttractionDescription", new { AttractionName, AttractionStatus, AttractionDescription });
            }
        }

        public void AttractionStatus_Update(int AttractionID, string status)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.AttractionStatus_Update @AttractionID, @status", new { AttractionID, status });
            }
        }

        public void Attraction_Delete(int AttractionID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Attraction_Delete @AttractionID ", new { AttractionID });
            }
        }
        public List<Attraction> GetLastAttraction()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Attraction>($"select TOP 1 * from Attraction ORDER BY AttractionID DESC").ToList();
                return output;
            }
        }


    }
}

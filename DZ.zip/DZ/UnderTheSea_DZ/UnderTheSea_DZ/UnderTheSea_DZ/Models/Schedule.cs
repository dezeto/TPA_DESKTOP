﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class Schedule
    {

        Ride r = new Ride();

        public int ScheduleID { get; set; }

        public DateTime ScheduleDate { get; set; }

        public int RideID { get; set; }

        public string ScheduleStatus { get; set; }

        public List<Schedule> GetAllSchedule()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Schedule>($"select * from Schedule").ToList();
                return output;
            }
        }

        public List<Schedule> GetSchedule(int scheduleID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Schedule>($"select * from Schedule where Schedule.scheduleID = "+scheduleID+"").ToList();
                return output;
            }
        }

        public void Schedule_Insert(DateTime date, int rideID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Schedule_Insert @date, @RideID", new { date, rideID });
            }
        }

        public void Schedule_Update(int scheduleID, string scheduleDesc)
        {   
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Schedule_Update @scheduleID, @scheduleDesc", new { scheduleID, scheduleDesc});
            }   
        }

        public void Schedule_Delete(int scheduleID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Schedule_Delete @ScheduleID", new { scheduleID });
            }
        }
        public List<Schedule> GetLastSchedule()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Schedule>($"select TOP 1 * from Schedule ORDER BY ScheduleID DESC").ToList();
                return output;
            }
        }

        public string GetRideName(int RideID)
        {
            List<Ride> output = r.GetRide(RideID);
            return output.ElementAt(0).RideName;
        }

        public string GetRideStatus(int RideID)
        {
            List<Ride> output = r.GetRide(RideID);
            return output.ElementAt(0).RideStatus;
        }
    }
}

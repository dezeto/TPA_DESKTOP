﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class Advertisement
    {
        public int AdvertisementID { get; set; }
        public string AdvertisementName { get; set; }
        public string AdvertisementType { get; set; }
        public string AdvertisementDescription { get; set; }
        public string Status{ get; set; }

        public Advertisement()
        {

        }

        public List<Advertisement> GetAdvertisement(int AdvertisementID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Advertisement>($"select * from Advertisement where Advertisement.AdvertisementID = " + AdvertisementID + "").ToList();
                return output;
            }
        }

        public List<Advertisement> GetAllAdvertisement()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Advertisement>($"select * from Advertisement").ToList();
                return output;
            }
        }

        public List<Advertisement> GetAllAdvertisementWithNoDeleted()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Advertisement>($"select * from Advertisement where AdvertisementDescription NOT LIKE 'DELETED'").ToList();
                return output;
            }
        }


        public List<Request> GetPurchaseAdvertisement(int id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select * from Request where senderID = 9 AND ReceiverID = 6 AND AdditionalID = " + id +"").ToList();
                return output;
            }
        }

        public List<Request> GetFundAdvertisement(int id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select * from Request where senderID = 9 AND ReceiverID = 7 AND AdditionalID = " + id +"").ToList();
                return output;
            }
        }

        public List<Advertisement> GetAllFundAdvertisement()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Advertisement>($"select * from Advertisement where receiverID = 7").ToList();
                return output;
            }
        }

        public List<Advertisement> GetAllManagerAdvertisement()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Advertisement>($"select * from Advertisement where receiverID =11").ToList();
                return output;
            }
        }

        public void Advertisement_Insert(string name, string type, string description, string status)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Advertisement_Insert @Name, @Type, @Description, @Status ", new { name, type, description, status});
            }
        }

        public void Advertisement_Delete(int AdvertisementID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Advertisement_Delete @AdvertisementID", new { AdvertisementID });
            }
        }

        public void Advertisement_Update(int advertisementID, string advertisementName, string type, string description)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Advertisement_Update @AdvertisementID, @AdvertisementName, @Type, @Description", new { advertisementName, advertisementID, type, description });
            }
        }

        public void AdvertisementStatus_Update(int advertisementID, string status)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.AdvertisementStatus_Update @AdvertisementID, @Status", new { advertisementID, status});
            }       
        }

        public List<Advertisement> GetLastAdvertisement()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Advertisement>($"select TOP 1 * from Advertisement ORDER BY AdvertisementID DESC").ToList();
                return output;
            }
        }
    }
}

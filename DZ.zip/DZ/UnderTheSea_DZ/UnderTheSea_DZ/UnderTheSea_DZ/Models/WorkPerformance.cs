﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class WorkPerformance
    {
        public int EmployeeID{ get; set; }
        public int WorkPerformanceID { get; set; }
        public string EmployeeName{ get; set; }
        public string WorkPerformanceDescription{ get; set; }

        public WorkPerformance()
        {
            
        }


        public List<WorkPerformance> GetWorkPerformance(int WorkPerformanceID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<WorkPerformance>($"select * from WorkPerformance where WorkPerformance.WorkPerformanceID = " + WorkPerformanceID + "").ToList();
                return output;
            }
        }

        public List<WorkPerformance> GetAllWorkPerformance()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<WorkPerformance>($"select * from WorkPerformance").ToList();
                return output;
            }
        }

        public List<WorkPerformance> GetAllWorkPerformanceWithNoDeleted()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<WorkPerformance>($"select * from WorkPerformance where WorkPerformanceDescription NOT LIKE 'DELETED'").ToList();
                return output;
            }
        }


        public List<Request> GetPurchaseWorkPerformance(int id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select * from Request where senderID = 9 AND ReceiverID = 6 AND AdditionalID = " + id + "").ToList();
                return output;
            }
        }

        public List<Request> GetFundWorkPerformance(int id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Request>($"select * from Request where senderID = 9 AND ReceiverID = 7 AND AdditionalID = " + id + "").ToList();
                return output;
            }
        }

        public List<WorkPerformance> GetAllFundWorkPerformance()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<WorkPerformance>($"select * from WorkPerformance where receiverID = 7").ToList();
                return output;
            }
        }

        public List<WorkPerformance> GetAllManagerWorkPerformance()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<WorkPerformance>($"select * from WorkPerformance where receiverID =11").ToList();
                return output;
            }
        }

        public void WorkPerformance_Insert(int employeeID, string workPerformanceDescription)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.WorkPerformance_Insert @EmployeeID, @WorkPerformanceDescription", new { employeeID,  workPerformanceDescription });
            }
        }

        public void WorkPerformance_Delete(int WorkPerformanceID, string WorkPerformanceDescription)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.WorkPerformance_Delete @WorkPerformanceID, @WorkPerformanceDescription", new { WorkPerformanceID , WorkPerformanceDescription });
            }
        }

        public void WorkPerformance_Update(int WorkPerformanceID, string WorkPerformanceDescription)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.WorkPerformance_Update @WorkPerformanceID, @WorkPerformanceDescription", new { WorkPerformanceID, WorkPerformanceDescription});
            }
        }

        public void WorkPerformanceStatus_Update(int WorkPerformanceID, string status)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.WorkPerformanceStatus_Update @WorkPerformanceID, @Status", new { WorkPerformanceID, status });
            }
        }

        public List<WorkPerformance> GetLastWorkPerformance()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<WorkPerformance>($"select TOP 1 * from WorkPerformance ORDER BY WorkPerformanceID DESC").ToList();
                return output;
            }
        }


    }
}

﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class Tickets
    {
        public int TicketID { get; set; }
        public DateTime Date{ get; set; }
        public string Status { get; set; }

        public void Ticket_Insert()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Ticket_Insert");
            }
        }
        public void Ticket_Update(int TicketID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Ticket_Update @TicketID",new { TicketID});
            }
        }
        public void Ticket_Delete(int TicketID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Ticket_Delete @TicketID", new { TicketID });
            }
        }

        public List<Tickets> GetAllTicket()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Tickets>($"select * from Tickets").ToList();
                return output;
            }
        }

        public List<Tickets> GetTicket(int ticketID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Tickets>($"select * from Tickets where Tickets.TicketID = " + ticketID+ "").ToList();
                return output;
            }
        }

        public List<Tickets> GetLastTicket()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Tickets>($"select TOP 1 * from Tickets ORDER BY TicketID DESC").ToList();
                return output;
            }
        }

        public int checkTicketDate(int ticketID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Tickets>($"select * from Tickets where Tickets.TicketID =" + ticketID + "").ToList();
                return output.ElementAt(0).Date.Day ;
            }
        }


    }
}

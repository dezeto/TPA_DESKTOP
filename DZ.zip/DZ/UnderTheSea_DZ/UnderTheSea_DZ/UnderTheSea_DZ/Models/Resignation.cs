﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class Resignation
    {
        public int ResignationID{ get; set; }
        public int EmployeeID{ get; set; }

        
    }
}

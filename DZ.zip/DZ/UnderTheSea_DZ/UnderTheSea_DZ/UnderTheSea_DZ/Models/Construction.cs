﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.Models
{
    public class Construction
    {
        public int ConstructionID{ get; set; }
        public int RideID{ get; set; }

        public string RideName { get; set; }
        public string RideStatus { get; set; }

        public List<Construction> GetConstruction(int ConstructionID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Construction>($"select * from Construction where Construction.ConstructionID = " + ConstructionID + "").ToList();
                return output;
            }
        }
        public List<Construction> GetAllConstruction()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Construction>($"select * from Construction").ToList();
                return output;
            }
        }

        public List<Construction> GetAllConstructionForView()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Construction>($"select c.ConstructionID, c.RideID, RideName, RideStatus, RideDescription from Construction c join ride r on c.ConstructionID = r.ConstructionID ").ToList();
                return output;
            }
        }

        public List<Ride> GetAllRideWithNoConstruction()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Ride>($"select * from Ride where ConstructionID not in (select ConstructionID from Construction) OR RideStatus LIKE 'Waiting for constructing'").ToList();

                return output;
            }
        }
        public List<Ride> GetRide(int ConstructionID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Ride>($"select * from Ride where ConstructionID = " + ConstructionID + "").ToList();
                return output;
            }
        }




        public void Construction_Insert(int RideID, int ConstructionID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Construction_Insert @RideID, @ConstructionID", new { RideID, ConstructionID });
            }
        }

        public void ConstructionStatus_Update(int ConstructionID, string status)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.ConstructionStatus_Update @ConstructionID, @status", new { ConstructionID, status });
            }
        }

        public void Construction_Delete(int RideID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                connection.Execute("dbo.Construction_Delete @RideID ", new { RideID });
            }
        }
        public List<Construction> GetLastConstruction()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Construction>($"select TOP 1 * from Construction ORDER BY ConstructionID DESC").ToList();
                return output;
            }
        }





    }
}

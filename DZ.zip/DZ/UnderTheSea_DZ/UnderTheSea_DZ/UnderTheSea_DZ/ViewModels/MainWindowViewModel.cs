﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.ViewModels
{
    public class MainWindowViewModel : Conductor<object>
    {
        public bool valid { get; set; }
        public string desc { get; set; }

        public void ADButton()
        {
            ActivateItem(new AttractionDepartmentViewModel());
        }

        public void MDButton()
        {
            ActivateItem(new MaintenanceDepartmentViewModel());
        }

        public void PDButton()
        {
            ActivateItem(new PurchaseDepartmentViewModel());
        }

        public void RACDButton()
        {
            ActivateItem(new RideAndAttractionDepartmentViewModel(valid, desc));
        }

        public void CDButton()
        {
            ActivateItem(new ConstructionDepartmentViewModel());
        }

        public void AFDButton()
        {
            ActivateItem(new FundDepartmentViewModel());
        }

        public void SMDButton()
        {
            ActivateItem(new SalesMarketingDepartmentViewModel());
        }


        public void MGButton()
        {
            ActivateItem(new ManagerViewModel());
        }

        public void HRDButton()
        {
            ActivateItem(new HRDViewModel());
        }
    }

}

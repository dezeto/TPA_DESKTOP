﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class AddAttractionViewModel : Screen
    {
        Request req = new Request();
        Ride r = new Ride();
        Attraction a = new Attraction();
        public string Title { get; set; }
        public string TitleName { get; set; }
        public string NameBox { get; set; }
        public string type { get; set; }
        public string Description{ get; set; }
        public int selectedID { get; set; }
        public AddAttractionViewModel(int id, string title, string titleName,string typePop)
        {
            Title = title;
            TitleName = titleName;
            type = typePop;
            selectedID = id;
        }

        public void Add_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel(Title+" Request has been sent to Manager"));
            if (type == "ride")
            {
                Ride r = new Ride();
                r.Ride_Insert(NameBox, Title + " Request Has been sent to Manager", Description);

                req.Request_Insert(3,11,"Waiting for Confirmation",Title + " Desc : " + "Ride"+ Description,selectedID);

            }

            else if (type == "attraction")
            {
                Attraction a = new Attraction();
                a.Attraction_Insert(NameBox, Title + " Request Has been sent to Manager", Description);

                req.Request_Insert(3, 11, "Waiting for Confirmation", Title + " Desc : " + "Attraction" + Description, selectedID);
            }

            else if (type == "fund")
            {
                Attraction a = new Attraction();
                a.AttractionStatus_Update(selectedID, Title + " Request Has been sent to Accounting and Finance Department" + Description);
                req.Request_Insert(3, 7, "Waiting for Confirmation", Description,selectedID);
                r.RideStatus_Update(selectedID,"Waiting for confirmation for Fund Request");

            }

            else if (type == "purchase")
            {
                Attraction a = new Attraction();
                a.AttractionStatus_Update(selectedID, Title + " Request Has been sent to Purchasing Department" + Description);

            }

            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

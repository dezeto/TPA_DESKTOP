﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class FireEmployeeViewModel : Screen
    {
        private int employeeId;
        public string DescriptionTextBox { get; set; }

        public FireEmployeeViewModel(int employeeId)
        {
            this.employeeId = employeeId;
        }

        public void Fire_Button()
        {
            Request r = new Request();
            r.Request_Insert(10, 11, "Waiting for confirmation", "Employee Resignation as not good enough -HRD- " + DescriptionTextBox, employeeId);
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class ConstructionDepartmentViewModel : Screen
    {

        public Construction SelectedConstruction { get; set; }
        public BindableCollection<Construction> Constructions { get; set; }

        public ConstructionDepartmentViewModel()
        {
            Construction c = new Construction();
            Constructions = new BindableCollection<Construction>(c.GetAllConstructionForView());
        }

        public void Update_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopUpForUpdateScheduleViewModel("Update Ride Status",SelectedConstruction.RideID,"construction"));
        }

        public void Add_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new AddConstructionViewModel());
        }

        public void Delete_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Construction has been stated as done"));
            TryClose();

            Construction c = new Construction();
            c.Construction_Delete(SelectedConstruction.RideID);
        }

        public void Purchase_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new RequestPurchaseFundViewModel(SelectedConstruction.RideID,"construction","purchase"));

        }

        public void Fund_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new RequestPurchaseFundViewModel(SelectedConstruction.RideID, "construction", "fund"));
        }

    }
}

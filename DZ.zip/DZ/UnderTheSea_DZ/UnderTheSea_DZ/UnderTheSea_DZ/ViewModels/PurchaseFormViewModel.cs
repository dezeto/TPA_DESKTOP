﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class PurchaseFormViewModel : Screen
    {
        Ride r = new Ride();
        Attraction a = new Attraction();
        Construction c = new Construction();
        Advertisement adv = new Advertisement();
        public string PurchaserNameBox{ get; set; }
        public DateTime DatePicker{ get; set; }
        public string PurchasePriceBox{ get; set; }

        public int id { get; set; }
        public PurchaseFormViewModel(int idPop)
        {
            DatePicker = DateTime.Now;
            id = idPop;
        }

        public void Ok_Button()
        {
            Request req = new Request();
            req.Request_Update(id,"Done");
            if (req.GetRequest(id).ElementAt(0).Description.Contains("Ride")) {
                r.RideStatus_Update(req.GetRequest(id).ElementAt(0).additionalID, "Purchases Accepted " + "Name : "+ PurchaserNameBox + " Date bought : " +DatePicker + " Total Price : " + PurchasePriceBox);
            }

            else if (req.GetRequest(id).ElementAt(0).Description.Contains("Attraction"))
            {
                a.AttractionStatus_Update(req.GetRequest(id).ElementAt(0).additionalID, "Purchases Accepted " + "Name : " + PurchaserNameBox + " Date bought : " + DatePicker + " Total Price : " + PurchasePriceBox);
            }

            else if (req.GetRequest(id).ElementAt(0).Description.Contains("Construction"))
            {
                r.RideStatus_Update(req.GetRequest(id).ElementAt(0).additionalID, "Purchases Accepted " + "Name : " + PurchaserNameBox + " Date bought : " + DatePicker + " Total Price : " + PurchasePriceBox);
            }

            else if (req.GetRequest(id).ElementAt(0).Description.Contains("Sales"))
            {
                adv.AdvertisementStatus_Update(req.GetRequest(id).ElementAt(0).additionalID, "Purchases Accepted " + "Name : " + PurchaserNameBox + " Date bought : " + DatePicker + " Total Price : " + PurchasePriceBox);
            }
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

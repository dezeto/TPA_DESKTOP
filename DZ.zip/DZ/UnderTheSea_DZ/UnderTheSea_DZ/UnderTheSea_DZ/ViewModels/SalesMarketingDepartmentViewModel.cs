﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class SalesMarketingDepartmentViewModel : Screen
    {
        Advertisement a = new Advertisement();
        public Advertisement SelectedAdvertisement{ get; set; }

        public BindableCollection<Advertisement> Advertisements { get; set; }

        public SalesMarketingDepartmentViewModel()
        {

            Advertisements= new BindableCollection<Advertisement>(a.GetAllAdvertisementWithNoDeleted());
        }

        public void Add_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new AddAdvertisementViewModel());
        }

        public void Update_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new UpdateAdvertisementViewModel(SelectedAdvertisement.AdvertisementID));
        }

        public void Delete_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Advertisement Deleted"));
            a.Advertisement_Delete(SelectedAdvertisement.AdvertisementID);
        }

        public void Purchase_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new RequestPurchaseFundViewModel(SelectedAdvertisement.AdvertisementID,"advertisement", "purchase"));
        }


        public void Fund_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new RequestPurchaseFundViewModel(SelectedAdvertisement.AdvertisementID, "advertisement", "fund"));
        }

    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class RideAndAttractionDepartmentViewModel : Screen
    {
        Request r = new Request();
        public Ride SelectedRide { get; set; }
        public Attraction SelectedAttraction { get; set; }
        public BindableCollection<Ride> Rides { get; set; }
        public BindableCollection<Attraction> Attractions { get; set; }
        
        public RideAndAttractionDepartmentViewModel(Boolean valid, string desc)
        {
            Ride r = new Ride();
            Rides = new BindableCollection<Ride>(r.GetAllRide());

            Attraction a = new Attraction();
            Attractions = new BindableCollection<Attraction>(a.GetAllAttraction());
            if (valid)
            {
                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new PopMessageViewModel(desc));
            }
        }
        public void AddAttraction_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new AddAttractionViewModel(SelectedAttraction.AttractionID,"Add Attraction", "Attraction Name","attraction"));
        }

        public void DeleteAttraction_Button()
        {

            if (SelectedAttraction.AttractionStatus.Contains("Manager has approved your request"))
            {
                Attraction a = new Attraction();
                a.AttractionStatus_Update(SelectedRide.RideID, "Deleted");
            }
            else
            {
                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new RequestRidePopUpViewModel("Delete Attraction", SelectedAttraction.AttractionID, "attraction"));

            }

            //Attraction a = new Attraction();
            //a.Attraction_Delete(SelectedAttraction.AttractionID);
        }

        public void UpdateAttraction_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new RequestRidePopUpViewModel("Update Attraction",SelectedAttraction.AttractionID,"attraction"));

            Attraction a = new Attraction();
            a.AttractionStatus_Update(SelectedAttraction.AttractionID,"Update Attraction Request has been sent to Manager - ");
        }

        public void AddRide_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new AddAttractionViewModel(SelectedRide.RideID,"Add Ride", "Ride Name","ride"));
        }

        public void DeleteRide_Button()
        {
            if (SelectedRide.RideStatus.Contains("Manager has approved your request"))
            {
                Ride ride = new Ride();
                ride.RideStatus_Update(SelectedRide.RideID, "Deleted");
            } 

            else
            {
                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new RequestRidePopUpViewModel("Delete Ride", SelectedRide.RideID, "ride"));

            }
            //Ride r = new Ride();
            //r.Ride_Delete(SelectedRide.RideID);
        }

        public void UpdateRide_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new RequestRidePopUpViewModel("Update Ride",SelectedRide.RideID,"ride"));
        }

        public void PurchaseRequest_Button()
        {
            IWindowManager manager = new WindowManager();
            if (SelectedAttraction == null)
            {
                manager.ShowWindow(new RequestPurchaseFundViewModel(SelectedRide.RideID, "ride", "purchase"));
            }
            else if (SelectedRide == null)
            {
                manager.ShowWindow(new RequestPurchaseFundViewModel(SelectedAttraction.AttractionID,"attraction","purchase"));
            }
        }


        public void FundRequest_Button()
        {
            IWindowManager manager = new WindowManager();
            if (SelectedAttraction == null)
            {
                manager.ShowWindow(new RequestPurchaseFundViewModel(SelectedRide.RideID, "ride", "fund"));
            }
            else if (SelectedRide == null)
            {
                manager.ShowWindow(new RequestPurchaseFundViewModel(SelectedAttraction.AttractionID, "attraction", "fund"));
            }
        }

        public void Construction_Button()
        {
           if (SelectedRide.RideStatus.Contains("Manager has approved your request"))
            {
                Ride r = new Ride();
                r.RideStatus_Update(SelectedRide.RideID,"Waiting for constructing");
            }
        }
    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class PurchaseDepartmentViewModel
    {

        Request r = new Request();
        public PurchaseRequest SelectedPurchase { get; set; }
        public BindableCollection<PurchaseRequest> Purchases { get; set; }

        public class PurchaseRequest
        {
            public int RequestID { get; set; }
            public string DepartmentName { get; set; }
            public string  DateNeeded { get; set; }
            public string Items { get; set; }
            public string Status{ get; set; }
        }

        public PurchaseDepartmentViewModel()
        {
            Request r = new Request();
            Department d = new Department();
            Purchases = new BindableCollection<PurchaseRequest>();
            foreach(Request req in r.GetAllPurchaseRequest())
            {
                Object[] list = req.Description.Split('-');
                Purchases.Add(new PurchaseRequest
                {
                    RequestID = req.RequestID,
                    DepartmentName = d.GetDepartment(req.SenderID).ElementAt(0).DepartmentName,
                    DateNeeded = list[0].ToString(),
                    Items = list[2].ToString(),
                    Status = req.Status
                });
            }

        }

        public void RequestFund_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PurchaseFundRequestPopViewModel(r.GetRequest(SelectedPurchase.RequestID).ElementAt(0).ReceiverID,SelectedPurchase.RequestID,"Fund Request","Amount Fund",SelectedPurchase.Items,SelectedPurchase.RequestID));
            int tempID = r.GetRequest(SelectedPurchase.RequestID).ElementAt(0).SenderID;
            if (tempID == 9)
            {
                Advertisement adv = new Advertisement();
                adv.AdvertisementStatus_Update(r.GetRequest(tempID).ElementAt(0).additionalID,"Purchase has request for fund");
            }

            if (tempID == 4)
            {
                Ride ride = new Ride();
                ride.RideStatus_Update(r.GetRequest(tempID).ElementAt(0).additionalID, "Purchase has request for fund");
            }

        }

        public void Delete_Button()
        {
            Request r = new Request();
            r.Request_Update(SelectedPurchase.RequestID,"Deleted");
        }

        public void Purchase_Button()
        {
            if (SelectedPurchase.Status == "Fund Accepted")
            {
                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new PurchaseFormViewModel(SelectedPurchase.RequestID));
            }

            else
            {
                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new PopMessageViewModel(SelectedPurchase.Status));
            }
        }

    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.ViewModels
{
    public class AddNewEmployeeViewModel : Screen
    {
        public string NameTextBox{ get; set; }
        public string UsernameTextBox { get; set; }
        public string DepartmentIDTextBox { get; set; }
        public string DivisionIDTextBox { get; set; }
        public string SalaryTextBox { get; set; }

        public void Ok_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("New employee is added"));
            Employee e = new Employee();
            e.Employee_Insert(UsernameTextBox, "DZ20-1", int.Parse(DepartmentIDTextBox), int.Parse(DivisionIDTextBox), "Working",int.Parse(SalaryTextBox),"-",NameTextBox,"-");
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.ViewModels
{


    public class PopMessageViewModel : Screen
    {

        public string ErrorText { get; set; }

        public PopMessageViewModel(string error)
        {
            ErrorText = error;
        }

        public void Ok_Button()
        {
            TryClose();
        }
    }
}

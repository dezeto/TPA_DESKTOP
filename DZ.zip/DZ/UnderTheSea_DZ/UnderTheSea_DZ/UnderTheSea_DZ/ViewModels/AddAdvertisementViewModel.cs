﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class AddAdvertisementViewModel : Screen
    {

        Advertisement a = new Advertisement();
        public string AdvertisementNameBox{ get; set; }
        public string AdvertisementName { get; set; }
        public string TypeTextBox { get; set; }
        public int MyProperty { get; set; }
        public string DescriptionTextBox{ get; set; }


        public AddAdvertisementViewModel()
        {

        }

        public void Ok_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Advertisment has been made"));

            a.Advertisement_Insert(AdvertisementNameBox,TypeTextBox, DescriptionTextBox,"new");
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }

    }
}

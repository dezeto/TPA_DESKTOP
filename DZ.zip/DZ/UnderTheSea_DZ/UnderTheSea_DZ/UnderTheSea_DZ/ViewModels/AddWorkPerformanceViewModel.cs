﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class AddWorkPerformanceViewModel : Screen
    {
        WorkPerformance wp = new WorkPerformance();
        public string EmployeeIDTextBox { get; set; }
        public string WorkPerformanceTextBox{ get; set; }

        public int selectedID{ get; set; }
        public AddWorkPerformanceViewModel()
        {
        }

        public void Add_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Add new Work Performance"));
            int wpID = int.Parse(EmployeeIDTextBox);
            wp.WorkPerformance_Insert(wpID,WorkPerformanceTextBox);
            TryClose();     
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

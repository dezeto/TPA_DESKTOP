﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.ViewModels
{
    public class ManagePermitRequestViewModel : Screen
    {
        Employee e = new Employee();
        public Employee SelectedPermitRequest { get; set; }
        public BindableCollection<Employee> PermitRequests { get; set; }
        public ManagePermitRequestViewModel()
        {

            PermitRequests = new BindableCollection<Employee>(e.GetEmployeeWithPermitRequest());
        }

        public void Accept_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Request Permit Accepted"));
            e.PermitRequest_Update(SelectedPermitRequest.EmployeeId,"Accepted");
            TryClose();
        }

        public void Decline_Button()
        {

            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Request Permit Rejected"));
            e.PermitRequest_Update(SelectedPermitRequest.EmployeeId, "Rejected");
            TryClose();
        }

    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class RequestPurchaseFundViewModel : Screen
    {
        Request req = new Request();
        Ride r = new Ride();
        Attraction a = new Attraction();
        Construction c = new Construction();
        Advertisement adv = new Advertisement();
        public string Title{ get; set; }
        public string TitleName{ get; set; }

        public string NameBox{ get; set; }

        public DateTime RequestDatePicker{ get; set; }

        public string Description{ get; set; }
        public int selectedID{ get; set; }
        public string type{ get; set; }

        public string typeRequest { get; set; }

        public RequestPurchaseFundViewModel(int idPop, string typePop, string typeRequestPop)
        {
            if (typeRequestPop == "fund")
            {
                Title = "Fund Request Form";
                TitleName = "Fund Amount";
            } 
            else if (typeRequestPop == "purchase")
            {
                Title = "Purchase Request Form";
                TitleName = "Purchase Amount";
            }

            RequestDatePicker = DateTime.Now;
            selectedID = idPop;
            type = typePop;
            typeRequest = typeRequestPop;
        }

        public void Add_Button()
        {
            if (typeRequest == "fund")
            {
                if (type == "ride")
                {
                    r.RideStatus_Update(selectedID, "Waiting for confirmation for Fund Request");
                    req.Request_Insert(3, 7, "Waiting for Confirmation", RequestDatePicker.ToString() + "-" + "Ride" + "-" + Description, selectedID);
                }

                else if (type == "attraction")
                {
                    a.AttractionStatus_Update(selectedID, "Waiting for confirmation for Fund Request");
                    req.Request_Insert(3, 7, "Waiting for Confirmation", RequestDatePicker.ToString() + "-" + "Attraction" + "-" + Description, selectedID);
                }

                else if (type == "construction")
                {
                    r.RideStatus_Update(selectedID, "Waiting for confirmation for Fund Request");
                    req.Request_Insert(4, 7, "Waiting for Confirmation", RequestDatePicker.ToString() + "-" + "Construction" + "-" + Description, selectedID);
                }


                else if (type == "advertisement")
                {
                    adv.AdvertisementStatus_Update(selectedID, "Waiting for confirmation for Fund Request");
                    req.Request_Insert(9, 7, "Waiting for confirmation", RequestDatePicker.ToString() + "-" + "Sales" + "-" + Description, selectedID);
                }


            }

            else if (typeRequest == "purchase")
            {

                if (type == "ride")
                {
                    r.RideStatus_Update(selectedID, "Waiting for confirmation for Purchase Request");
                    req.Request_Insert(3, 6, "Waiting for Confirmation", RequestDatePicker.ToString() + "-" + "Ride" + "-" + Description, selectedID);

                }

                else if (type == "attraction")
                {
                    a.AttractionStatus_Update(selectedID, "Waiting for confirmation for Purchase Request");
                    req.Request_Insert(3, 6, "Waiting for Confirmation", RequestDatePicker.ToString() + "-" + "Attraction" + "-" + Description, selectedID);
                }

                else if (type == "construction")
                {
                    r.RideStatus_Update(selectedID, "Waiting for confirmation for Fund Request");
                    req.Request_Insert(4, 6, "Waiting for Confirmation", RequestDatePicker.ToString() + "-" + "Construction" + "-" + Description, selectedID);
                }

                else if (type == "advertisement")
                {
                    adv.AdvertisementStatus_Update(selectedID, "Waiting for confirmation for Purchase Request");
                    req.Request_Insert(9, 6, "Waiting for confirmation", RequestDatePicker.ToString() + "-" + "Sales" + "-" + Description, selectedID);
                }


            }
            TryClose(); 
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class AddNewRideScheduleViewModel : Screen
    {
        public DateTime ScheduleDatePicker { get; set; }

        public Ride SelectedRide { get; set; }
        public BindableCollection<Ride> Ride { get; set; }

        public AddNewRideScheduleViewModel()
        {
            Ride db = new Ride();
            Ride = new BindableCollection<Ride>(db.GetAllRideWithNoSchedule());
            ScheduleDatePicker = DateTime.Now;
        }

        public void Add_Button()
        {
            Schedule s = new Schedule();
            s.Schedule_Insert(ScheduleDatePicker, SelectedRide.RideID);
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Schedule inserted to " + SelectedRide.RideName + ""));
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;
using UnderTheSea_DZ.Views;

namespace UnderTheSea_DZ.ViewModels
{
    public class PopUpForUpdateScheduleViewModel : Screen
    {
        public string title{ get; set; }
        public string Description_Text { get; set; }

        public int selectedId;
        public string type{ get; set; }

        public PopUpForUpdateScheduleViewModel(string titlePop, int id, string typePop)
        {
            title = titlePop;
            Description_Text = "";
            selectedId = id;
            type = typePop;
        }

        public void Ok_Button()
        {
            if (String.IsNullOrEmpty(Description_Text))
            {
                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new PopMessageViewModel("Description text may not empty"), null, null);
            }

            else
            {
                TryClose();
                if (type == "schedule")
                {
                    Schedule s = new Schedule();
                    s.Schedule_Update(selectedId, Description_Text);
                }

                else if (type == "construction")
                {
                    Ride r = new Ride();
                    r.RideStatus_Update(selectedId, Description_Text);
                }

            }

        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class UpdateAdvertisementViewModel : Screen
    {
        Advertisement a = new Advertisement();
        public string AdvertisementNameBox { get; set; }
        public string AdvertisementName { get; set; }
        public string TypeTextBox { get; set; }
        public string DescriptionTextBox { get; set; }

        public int selectedID { get; set; }
        public UpdateAdvertisementViewModel(int idPop)
        {
            selectedID = idPop;
        }

        public void Ok_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Advertisement Updated"));
            a.Advertisement_Update(selectedID,AdvertisementNameBox, TypeTextBox,DescriptionTextBox);
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }


    }
}

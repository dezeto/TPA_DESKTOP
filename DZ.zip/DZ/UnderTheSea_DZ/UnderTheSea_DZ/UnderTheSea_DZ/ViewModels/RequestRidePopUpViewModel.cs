﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class RequestRidePopUpViewModel : Screen
    {
        Request req = new Request();
        public string Title{ get; set; }
        public string Description{ get; set; }

        public int selectedID;
        public string type;
        public string requestTitle;

        public RequestRidePopUpViewModel(string title,int id, string typePop)
        {
            Title = title;
            requestTitle = title;
            selectedID = id;
            type = typePop;
        }

        public void Send_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel(requestTitle + " has been send to Manager"));
                        
            if (type == "ride")
            {
                Ride r = new Ride();
                r.RideStatus_Update(selectedID, requestTitle + " Request has been sent to Manager - " + Description);
                req.Request_Insert(3, 11, "Waiting for repsonse ", requestTitle + " Desc : " + Description + "Ride",selectedID);

            }

            else if (type == "attraction")
            {
                Attraction a = new Attraction();
                a.AttractionStatus_Update(selectedID, requestTitle + " Request has been sent to Manager - " + Description);
                req.Request_Insert(3, 11, "Waiting for repsonse ", requestTitle + " Desc : " + Description + "Attraction", selectedID);

            }




            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class UpdateWorkPerformanceViewModel : Screen
    {
        WorkPerformance wp = new WorkPerformance();
        public int selectedID { get; set; }
        public string Description { get; set; }
        public UpdateWorkPerformanceViewModel(int idPop)
        {
            selectedID = idPop;
        }

        public void Ok_Button()
        {
            wp.WorkPerformance_Update(selectedID, Description);
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

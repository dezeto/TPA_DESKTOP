﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class RaiseEmployeeSalaryViewModel : Screen
    {
        public string SalaryTextBox{ get; set; }
        public string DescriptionTextBox { get; set; }

        public int selectedID{ get; set; }
        public RaiseEmployeeSalaryViewModel(int idPop)
        {
            selectedID = idPop;
        }

        public void Ok_Button()
        {
            Employee e = new Employee();
            Request r = new Request();

            r.Request_Insert(10, 11, "Waiting for Confirmation", "Raise Salary for-" + SalaryTextBox +  "-to "+ e.GetEmployee(selectedID).ElementAt(0).Name + "-HRD-" +" Reason : " + DescriptionTextBox,selectedID);

            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }

    }
}

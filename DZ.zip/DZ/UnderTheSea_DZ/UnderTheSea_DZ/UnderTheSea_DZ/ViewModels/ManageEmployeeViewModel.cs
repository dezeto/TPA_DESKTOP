﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class ManageEmployeeViewModel : Screen
    {
        Employee e = new Employee();

        IWindowManager manager = new WindowManager();
        public Employee SelectedEmployee { get; set; }
        public BindableCollection<Employee> Employees { get; set; }


        public ManageEmployeeViewModel()
        {
            Employees = new BindableCollection<Employee>(e.GetAllEmployee());
        }


        public void Add_Button()
        {
            manager.ShowWindow(new AddNewEmployeeViewModel());
        }


        public void Update_Button()
        {
            manager.ShowWindow(new UpdateEmployeeViewModel(SelectedEmployee.EmployeeId));
        }


        public void Delete_Button()
        {
            Employee e = new Employee();
            e.Employee_Delete(SelectedEmployee.EmployeeId);
            manager.ShowWindow(new PopMessageViewModel("Employee data has been deleted"));
        }


        public void RaiseSalary_Button()
        {
            manager.ShowWindow(new RaiseEmployeeSalaryViewModel(SelectedEmployee.EmployeeId));
        }

        public void FireEmployee_Button()
        {
            manager.ShowWindow(new FireEmployeeViewModel(SelectedEmployee.EmployeeId));

        }
    }
}

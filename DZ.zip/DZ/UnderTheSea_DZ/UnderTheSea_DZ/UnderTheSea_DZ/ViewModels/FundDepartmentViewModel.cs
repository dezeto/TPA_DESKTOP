﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class FundDepartmentViewModel : Screen
    {
        Request r = new Request();
        public Fund SelectedFund{ get; set; }
        public BindableCollection<Fund> Funds { get; set; }

        public class Fund
        {
            public int RequestID { get; set; }
            public string DepartmentName { get; set; }
            public string Status { get; set; }
            public string Description { get; set; }
        }

        public FundDepartmentViewModel()
        {
            Request r = new Request();
            Department d = new Department();
            Funds = new BindableCollection<Fund>();
            foreach (Request req in r.GetAllFundRequest())
            {
                //Object[] list = req.Description.Split('-');
                Funds.Add(new Fund
                {
                    RequestID = req.RequestID,
                    DepartmentName = d.GetDepartment(req.SenderID).ElementAt(0).DepartmentName,
                    Status = req.Status,
                    Description = req.Description
                });
            }
        }


        public void Accept_Button()
        {
            Ride ride = new Ride();
            Attraction a = new Attraction();
            Advertisement adv = new Advertisement();
            r.Request_Update(SelectedFund.RequestID,"Accepted");
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Request Fund for RequestID : " + SelectedFund.RequestID + " had been approved"));
            if (r.GetRequest(SelectedFund.RequestID).ElementAt(0).SenderID == 6)
            {
                r.Request_Update(r.GetRequest(SelectedFund.RequestID).ElementAt(0).additionalID,"Fund Accepted");
            }

            else if (r.GetRequest(SelectedFund.RequestID).ElementAt(0).SenderID == 4)
            {
                ride.RideStatus_Update(r.GetRequest(SelectedFund.RequestID).ElementAt(0).additionalID, "Fund Accepted");
            }

            else if (r.GetRequest(SelectedFund.RequestID).ElementAt(0).SenderID == 3)
            {
                if (r.GetRequest(SelectedFund.RequestID).ElementAt(0).Description.Contains("Ride"))
                {
                    ride.RideStatus_Update(r.GetRequest(SelectedFund.RequestID).ElementAt(0).additionalID, "Fund Accepted");
                }

                if (r.GetRequest(SelectedFund.RequestID).ElementAt(0).Description.Contains("Attraction"))
                {
                    a.AttractionStatus_Update(r.GetRequest(SelectedFund.RequestID).ElementAt(0).additionalID, "Fund Accepted");
                }
            }


            else if (r.GetRequest(SelectedFund.RequestID).ElementAt(0).SenderID == 9)
            {
                adv.AdvertisementStatus_Update(r.GetRequest(SelectedFund.RequestID).ElementAt(0).additionalID, "Fund Accepted");
            }



        }

        public void Reject_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new RejectFundViewModel(SelectedFund.RequestID));

        }
    }
}

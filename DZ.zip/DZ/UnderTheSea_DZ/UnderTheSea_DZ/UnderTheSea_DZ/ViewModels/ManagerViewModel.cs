﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class ManagerViewModel
    {
        Request r = new Request();
        Ride ride = new Ride();
        Attraction a = new Attraction();
        public Request SelectedRequest{ get; set; }
        public BindableCollection<Request> Requests { get; set; }
        public ManagerViewModel()
        {
            Requests = new BindableCollection<Request>(r.GetAllManagerRequest());
        }

        public void Approve_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Request has been accepted"));
            r.Request_Update(SelectedRequest.RequestID,"Manager has approved your request");
            if (SelectedRequest.SenderID == 3)
            {

                if (SelectedRequest.Description.Contains("Ride"))
                {
                    if (SelectedRequest.Description.Contains("Add"))
                    {
                        ride.RideStatus_Update(ride.GetLastRide().ElementAt(0).RideID, "Manager has approved your request");
                    }
                    else
                    {
                        ride.RideStatus_Update(SelectedRequest.additionalID, "Manager has approved your request");

                    }

                }


                if (SelectedRequest.Description.Contains("Attraction"))
                {
                    if (SelectedRequest.Description.Contains("Add"))
                    {
                        a.AttractionStatus_Update(a.GetLastAttraction().ElementAt(0).AttractionID, "Manager has approved your request");
                    }
                    else
                    {
                        a.AttractionStatus_Update(SelectedRequest.additionalID, "Manager has approved your request");

                    }

                }


            }
            else if (SelectedRequest.Description.Contains("Resignation"))
            {
                Employee e = new Employee();
                e.FireEmployee(SelectedRequest.additionalID);
            }
            else if (SelectedRequest.Description.Contains("HRD"))
            {
                Employee e = new Employee();
                String[] temp = SelectedRequest.Description.Split('-');
                string salary = temp[1];
                e.RaiseEmployeeSalary(SelectedRequest.additionalID, int.Parse(salary));
            }


        }

        public void Reject_Button()
        {

            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Request has been rejected"));
            r.Request_Update(SelectedRequest.RequestID, "Manager has rejected your request");
            if (SelectedRequest.SenderID == 3)
            {
                if (SelectedRequest.Description.Contains("Ride"))
                {
                    if (SelectedRequest.Description.Contains("Add"))
                    {
                        ride.RideStatus_Update(ride.GetLastRide().ElementAt(0).RideID, "Manager has rejected your request");
                    }
                    else
                    {
                        ride.RideStatus_Update(SelectedRequest.additionalID, "Manager rejected your request");

                    }

                }


                if (SelectedRequest.Description.Contains("Attraction"))
                {
                    if (SelectedRequest.Description.Contains("Add"))
                    {
                        a.AttractionStatus_Update(a.GetLastAttraction().ElementAt(0).AttractionID, "Manager has rejected your request");
                    }
                    else
                    {
                        a.AttractionStatus_Update(SelectedRequest.additionalID, "Manager has rejected your request");

                    }
                }


            }

            else if (SelectedRequest.Description.Contains("HRD"))
            {
                manager.ShowWindow(new PopMessageViewModel("Manager has rejected for Raise employee Salary"));
            }
        }
    }
}

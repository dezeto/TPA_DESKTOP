﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class PurchaseFundRequestPopViewModel : Screen
    {
        public string Title { get; set; }
        public string TitleName{ get; set; }
        public string  NameBox{ get; set; }
        public string Description{ get; set; }
        public int senderId { get; set; }
        public int id { get; set; }
        public string desc { get; set; }

        public int rowID { get; set; }
        public PurchaseFundRequestPopViewModel(int idSenderPop,int idPop, string title, string subtitle, string descPop, int rowIDPop)
        {
            senderId = idSenderPop;
            id = idPop;
            Title = title;
            TitleName = subtitle;
            desc = descPop;
            rowID = rowIDPop;
        }

        public void Ok_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel(Title + "been send to Accounting and Finance Department"));
            Request r = new Request();
            r.Request_Insert(senderId, 7, "Waiting for Fund Request Confirmation",NameBox + " for " + desc,rowID);
            r.Request_Update(id, "Waiting for Fund Request Confirmation");
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }   
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class HRDViewModel : Screen
    {

        public WorkPerformance SelectedWorkPerformance { get; set; }
        public BindableCollection<WorkPerformance> WorkPerformances { get; set; }
        public HRDViewModel()
        {
            WorkPerformance wp = new WorkPerformance();
            Employee e = new Employee();
            WorkPerformances = new BindableCollection<WorkPerformance>();

            foreach (WorkPerformance wp2 in wp.GetAllWorkPerformance())
            {
                WorkPerformances.Add(new WorkPerformance {
                    EmployeeID = wp2.EmployeeID,
                    EmployeeName = e.GetEmployee(wp2.EmployeeID).ElementAt(0).Name,
                    WorkPerformanceID = wp2.WorkPerformanceID,
                    WorkPerformanceDescription = wp2.WorkPerformanceDescription
                });
            };
        }

        public void Add_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new AddWorkPerformanceViewModel());
        }


        public void Delete_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Delete Work Performance"));
            WorkPerformance wp = new WorkPerformance();
            wp.WorkPerformance_Delete(SelectedWorkPerformance.WorkPerformanceID, SelectedWorkPerformance.WorkPerformanceDescription);
        }


        public void Update_Button()
        {
            IWindowManager manager = new WindowManager();
            //manager.ShowWindow(new PopMessageViewModel("Work Performance Updated"));
            manager.ShowWindow(new UpdateWorkPerformanceViewModel(SelectedWorkPerformance.WorkPerformanceID));
        }

        public void Manage_Employee()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new ManageEmployeeViewModel());
        }

        public void FundRequest_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("New Fund Request has been send"));
            Request r = new Request();
            r.Request_Insert(10,7,"Waiting for confirmation","to pay employee's salary",0);
        }

        public void ManageRequestPermit_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new ManagePermitRequestViewModel());
        }
    }
}

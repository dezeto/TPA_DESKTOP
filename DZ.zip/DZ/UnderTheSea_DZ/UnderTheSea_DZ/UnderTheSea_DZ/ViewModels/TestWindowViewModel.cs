﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.ViewModels
{
    public class TestWindowViewModel : Screen
    {
        public BindableCollection<Employee> Employee { get; set; }
        public TestWindowViewModel()
        {
            Employee db = new Employee();
            Employee = new BindableCollection<Employee>(db.GetAllEmployee());
        }
        
    }
}

﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;
using UnderTheSea_DZ.Views;

namespace UnderTheSea_DZ.ViewModels
{
    public class MaintenanceDepartmentViewModel : Screen
    {
        public ScheduleViewModel SelectedSchedule { get; set; }

        public class ScheduleViewModel{

                public int ScheduleID { get; set; }
                public DateTime ScheduleDate { get; set; }
                public string RideName{ get; set; }
                public string ScheduleStatus { get; set; }
               
            }
        public BindableCollection<ScheduleViewModel> Schedule { get; set; }

        public MaintenanceDepartmentViewModel(){

            Schedule scheduleDA = new Schedule();
            Schedule = new BindableCollection<ScheduleViewModel>();

            foreach (Schedule schedule in scheduleDA.GetAllSchedule())
            {
                Schedule.Add(new ScheduleViewModel
                {
                    ScheduleID =  schedule.ScheduleID,
                    ScheduleDate =  schedule.ScheduleDate,
                    RideName =  schedule.GetRideName(schedule.RideID),
                    ScheduleStatus = schedule.ScheduleStatus
                });
            }
        }

        public void Add_Button()
        {
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new AddNewRideScheduleViewModel()); 
        }


        public void Update_Button()
        {
            Schedule s = new Schedule();
            if (SelectedSchedule.ScheduleStatus != "Deleted")
            {
                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new PopUpForUpdateScheduleViewModel("Update Schedule",SelectedSchedule.ScheduleID,"schedule"));
            }

            else
            {
                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new PopMessageViewModel("Schedule has been deleted"));
            }
        }

        public void Delete_Button()
        {
            Schedule s = new Schedule();
            s.Schedule_Delete(SelectedSchedule.ScheduleID);
        }
    }
}

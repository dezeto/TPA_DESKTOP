﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class RejectFundViewModel : Screen
    {
        public string Description { get; set; }
        public int id{ get; set; }
        public RejectFundViewModel(int idPop)
        {
            id = idPop;
        }

        public void Send_Button()
        {
            Request r = new Request();
            Ride ride = new Ride();
            Attraction a = new Attraction();
            Advertisement adv = new Advertisement();
            r.Request_Update(id, "Rejected : " + Description);
            IWindowManager manager = new WindowManager();
            manager.ShowWindow(new PopMessageViewModel("Fund for RequestId : " + id + " has been rejected"));
            if (r.GetRequest(id).ElementAt(0).SenderID == 6)
            {
                r.Request_Update(r.GetRequest(id).ElementAt(0).additionalID, "Fund Rejected : " + Description);
            }

            else if (r.GetRequest(id).ElementAt(0).SenderID == 4)
            {
                ride.RideStatus_Update(r.GetRequest(id).ElementAt(0).additionalID, "Fund Rejected : " + Description);
            }

            else if (r.GetRequest(id).ElementAt(0).SenderID == 3)
            {
                if (r.GetRequest(id).ElementAt(0).Description.Contains("Ride"))
                {
                    ride.RideStatus_Update(r.GetRequest(id).ElementAt(0).additionalID, "Fund Rejected : " + Description);
                }

                if (r.GetRequest(id).ElementAt(0).Description.Contains("Attraction"))
                {
                    a.AttractionStatus_Update(r.GetRequest(id).ElementAt(0).additionalID, "Fund Rejected : " + Description);
                }
            }

            else if (r.GetRequest(id).ElementAt(0).SenderID == 9)
            {
                adv.AdvertisementStatus_Update(r.GetRequest(id).ElementAt(0).additionalID, "Fund Rejected : " + Description);
            }


            r.Request_Update(id, "Rejected");
            //MainWindowViewModel m = new MainWindowViewModel();
            //m.valid = true;
            //m.desc = Description;
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

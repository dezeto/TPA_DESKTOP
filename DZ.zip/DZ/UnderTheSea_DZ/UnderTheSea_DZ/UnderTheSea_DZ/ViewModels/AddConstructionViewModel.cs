﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnderTheSea_DZ.Models;

namespace UnderTheSea_DZ.ViewModels
{
    public class AddConstructionViewModel : Screen
    {
        public string title{ get; set; }

        public Ride SelectedRide{ get; set; }

        public BindableCollection<Ride> Rides { get; set; }
        public AddConstructionViewModel()
        {
            Construction c = new Construction();
            Rides = new BindableCollection<Ride>(c.GetAllRideWithNoConstruction());
        }

        public void Add_Button()
        {
            Construction c = new Construction();
            c.Construction_Insert(SelectedRide.RideID, c.GetLastConstruction().ElementAt(0).ConstructionID+1);
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }

    }
}

﻿using Caliburn.Micro;
using MessagingToolkit.QRCode.Codec.Data;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using System.Windows.Forms;
using UnderTheSea_DZ.Models;
using UnderTheSea_DZ.Views;

namespace UnderTheSea_DZ.ViewModels
{
    public class AttractionDepartmentViewModel : Caliburn.Micro.Screen
    {
        public Tickets ticket = new Tickets();
        public Tickets SelectedTicket { get; set; }
        public string txtEncode { get; set; }
        public BindableCollection<Tickets> Tickets { get; set; }
        public AttractionDepartmentViewModel()
        {
            Tickets db = new Tickets();
            Tickets = new BindableCollection<Tickets>(db.GetAllTicket());
        }

        public List<Tickets> Check_Ticket()
        {
            
            DateTime now = DateTime.Now;
            int today = now.Date.Day;

            string ticketID = DecodeQRCode();

            if (ticketID == null)
            {
                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new PopMessageViewModel("test"), null, null);
                return null;
            }   

            else if ((ticket.checkTicketDate(int.Parse(ticketID)) - today == 1) || (ticket.checkTicketDate(int.Parse(ticketID)) - today == 0))
            {

                IWindowManager manager = new WindowManager();
                manager.ShowWindow(new PopMessageViewModel("Ticket is valid which is ordered in " + now.Date + ""), null, null);

            }


            return ticket.GetTicket(int.Parse(ticketID));
         }

        private void GenerateQRCode(int id)
        {
            using (SaveFileDialog sfd = new SaveFileDialog() { Filter = "JPEG|*.jpg", ValidateNames = true })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    MessagingToolkit.QRCode.Codec.QRCodeEncoder encoder = new MessagingToolkit.QRCode.Codec.QRCodeEncoder();
                    encoder.QRCodeScale = 8;
                    Bitmap bmp = encoder.Encode(id.ToString());
                    bmp.Save(sfd.FileName, ImageFormat.Jpeg);
                }
            }
        }

        private string DecodeQRCode()
        {
            string output =null;
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "JPEG|*jpg", ValidateNames = true, Multiselect = false })
            {

                if (ofd.ShowDialog() == DialogResult.OK)
                {

                    MessagingToolkit.QRCode.Codec.QRCodeDecoder decoder = new MessagingToolkit.QRCode.Codec.QRCodeDecoder();
                    
                    try
                    {
                        output = decoder.Decode(new QRCodeBitmapImage(Image.FromFile(ofd.FileName) as Bitmap));
                    }
                    catch (Exception)
                    {
                        output = null;
                    }

               }
            }
            return (output != null) ? output : null;
        }


        public void Create_Ticket()
        {
            Tickets t = new Tickets();
            t.Ticket_Insert();
            GenerateQRCode(t.GetLastTicket().ElementAt(0).TicketID);
        }

        public void Cancel_Ticket()
        {
            Tickets t = new Tickets();
            t.Ticket_Update(SelectedTicket.TicketID);
        }
        public void Delete_Ticket()
        {
            Tickets t = new Tickets();
            t.Ticket_Delete(SelectedTicket.TicketID);
        }

    }
}

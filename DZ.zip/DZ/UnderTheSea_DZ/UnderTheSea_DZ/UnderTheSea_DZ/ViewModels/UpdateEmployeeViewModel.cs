﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderTheSea_DZ.ViewModels
{
    public class UpdateEmployeeViewModel : Screen
    {
        public string StatusTextBox { get; set; }
        public string ViolationTextBox{ get; set; }

        public int selectedID{ get; set; }
        public UpdateEmployeeViewModel(int id)
        {
            selectedID = id;
        }

        public void Ok_Button(int id)
        {
            Employee e = new Employee();
            e.EmployeeStatus_Update(selectedID, StatusTextBox, ViolationTextBox);
            TryClose();
        }

        public void Cancel_Button()
        {
            TryClose();
        }
    }
}

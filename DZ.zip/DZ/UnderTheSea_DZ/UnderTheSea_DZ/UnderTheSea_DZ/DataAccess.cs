﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;

namespace UnderTheSea_DZ
{
    public class DataAccess
    {
        public List<Employee> GetEmployee(string EmployeeID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ConnectionString")))
            {
                var output = connection.Query<Employee>($"select * from Employee where EmployeeID = '{EmployeeID}'").ToList();
                return output;
            }
         }
    }
}
